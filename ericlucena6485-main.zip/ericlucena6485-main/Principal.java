package jogodavelha;

public class Principal {

	    public static void main(String[] args) {
	        new Interface(null, true).setVisible(true);
	    }
	}

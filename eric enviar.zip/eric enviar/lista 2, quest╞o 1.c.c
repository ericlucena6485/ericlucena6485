#include <stdio.h>
#include <stdlib.h>

void main(){

int A=8, B=4;

printf("soma de A+B: %d", A+B);
printf("\ndiferenca de A-B: %d", A-B);
printf("\nproduto de A*B: %d", A*B);
printf("\ndivisao de A/B: %d", A/B);
printf("\nresto da divisao de A/B: %d", A%B);

system("pause");
}

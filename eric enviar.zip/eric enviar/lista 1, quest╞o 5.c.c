#include <stdio.h>
#include <stdlib.h>

void main(){

 int numero1;

 printf("Digite um numero: ");
 scanf("%d", &numero1);
 printf("numero: %d", numero1);
 printf("foi o numero digitado");

 system("pause");

}

#include <stdio.h>
#include <stdlib.h>

int main(){

 //exercicio 1

 printf("sou um programa");

 system("pause");

 return 0;


}

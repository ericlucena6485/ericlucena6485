#include <stdio.h>
#include <stdlib.h>

void main(){

 int numero1;

 printf("Digite um numero: ");
 scanf("%d", &numero1);
 printf("voce digitou: %d", numero1);

 system("pause");

}

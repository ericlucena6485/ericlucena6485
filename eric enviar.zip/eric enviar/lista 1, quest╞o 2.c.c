#include <stdio.h>
#include <stdlib.h>

void main(){

 int numero;

 printf("Digite um numero");
 scanf("%d", &numero);
 printf("Numero digitado foi: %d", numero);

 system("pause");


}

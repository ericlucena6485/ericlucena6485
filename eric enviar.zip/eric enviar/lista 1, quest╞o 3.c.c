#include <stdio.h>
#include <stdlib.h>

void main(){

 int numero1, numero2;

 printf("Digite um numero: ");
 scanf("%d", &numero1);
 printf("digite outro numero: ");
 scanf("%d", &numero2);
 printf("numeros digitados foram: %d, %d ", numero2, numero1);

 system("pause");

}

#include<stdio.h>
#include<stdlib.h>

 int main(){
   int an,a1, r,n;
       an=0;

       printf("digite o valor do primeiro termo:\n");
       scanf("%d",&a1);
       printf("digite o valor do primeiro termo:\n");
       scanf("%d",&n);
       printf("digite o valor do primeiro termo:\n");
       scanf("%d",&r);

       an=a1+(n-1)*r;

       printf("o resultado da P.A e igual a: %d \n", an);


 return 0;
 }

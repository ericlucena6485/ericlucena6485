#include <stdio.h>
#include <stdlib.h>

 void main(){
    int a;

      printf("digite um numero: ");
      scanf("%d", &a);
      if(a%2==0){
         printf("o numero eh par");
      }else{
         printf("o numero eh impar");
      }

}

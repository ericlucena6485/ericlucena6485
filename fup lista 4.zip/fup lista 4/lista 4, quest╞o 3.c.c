
#include <stdio.h>
#include <stdlib.h>

 void main(){
   int numero;
   int soma=0;

   for(int i=1; i<=10; i++){
      printf("digite um numero: ");
      scanf("%d", &numero);

   soma=soma+numero;
 }

    printf("o somatorio eh: %d",soma);
    soma=soma+numero;
 }

